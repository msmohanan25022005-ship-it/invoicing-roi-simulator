
import React from 'react';

type ButtonVariant = 'default' | 'destructive' | 'outline' | 'ghost';
type ButtonSize = 'default' | 'sm' | 'lg';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  size?: ButtonSize;
}

const baseStyles = "inline-flex items-center justify-center rounded-md text-sm font-medium transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 disabled:opacity-50 disabled:pointer-events-none";

const variantStyles: Record<ButtonVariant, string> = {
  default: "bg-blue-600 text-white hover:bg-blue-700 focus:ring-blue-500",
  destructive: "bg-red-500 text-white hover:bg-red-600 focus:ring-red-500",
  outline: "border border-slate-300 bg-transparent hover:bg-slate-100 focus:ring-slate-400",
  ghost: "hover:bg-slate-100 text-slate-600",
};

const sizeStyles: Record<ButtonSize, string> = {
  default: "h-10 py-2 px-4",
  sm: "h-8 px-3 rounded-md",
  lg: "h-12 px-8 rounded-md",
};


export const Button: React.FC<ButtonProps> = ({ className, variant = 'default', size = 'default', ...props }) => {
  return (
    <button
      className={`${baseStyles} ${variantStyles[variant]} ${sizeStyles[size]} ${className}`}
      {...props}
    />
  );
};
