
import React from 'react';
import { SimulationInput } from '../types';
import { Input } from './ui/Input';
import { Label } from './ui/Label';

interface InputFormProps {
  inputs: SimulationInput;
  onInputChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

const formFields: { key: keyof SimulationInput; label: string; type: string; step?: string, description: string }[] = [
  { key: 'scenario_name', label: 'Scenario Name', type: 'text', description: 'A label for this saved scenario.' },
  { key: 'monthly_invoice_volume', label: 'Monthly Invoice Volume', type: 'number', description: 'Total invoices processed per month.' },
  { key: 'num_ap_staff', label: 'Number of AP Staff', type: 'number', description: 'Full-time staff managing invoicing.' },
  { key: 'avg_hours_per_invoice', label: 'Manual Hours per Invoice', type: 'number', step: '0.01', description: 'e.g., 0.17 for 10 minutes.' },
  { key: 'hourly_wage', label: 'Average Hourly Wage ($)', type: 'number', description: 'Fully-loaded cost per hour per staff.' },
  { key: 'error_rate_manual', label: 'Manual Error Rate (%)', type: 'number', step: '0.1', description: 'Estimated percentage of invoices with errors.' },
  { key: 'error_cost', label: 'Cost per Error ($)', type: 'number', description: 'Average cost to investigate and fix an error.' },
  { key: 'time_horizon_months', label: 'Time Horizon (Months)', type: 'number', description: 'The projection period for calculating total savings.' },
  { key: 'one_time_implementation_cost', label: 'Implementation Cost ($)', type: 'number', description: '(Optional) One-time setup and training cost.' },
];

const InputForm: React.FC<InputFormProps> = ({ inputs, onInputChange }) => {
  return (
    <form className="space-y-4">
       <h2 className="text-xl font-semibold text-slate-800 border-b pb-2">Business Metrics</h2>
      {formFields.map(field => (
        <div key={field.key}>
          <Label htmlFor={field.key}>{field.label}</Label>
          <Input
            id={field.key}
            name={field.key}
            type={field.type}
            step={field.step}
            value={inputs[field.key]}
            onChange={onInputChange}
            className="mt-1"
          />
           <p className="text-xs text-slate-500 mt-1">{field.description}</p>
        </div>
      ))}
    </form>
  );
};

export default InputForm;
