
import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { SimulationOutput } from '../types';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from './ui/Card';

interface SavingsChartProps {
  results: SimulationOutput;
}

const SavingsChart: React.FC<SavingsChartProps> = ({ results }) => {
  return (
    <Card className="shadow-lg">
      <CardHeader>
        <CardTitle>Cumulative Net Savings Over Time</CardTitle>
        <CardDescription>
          This chart shows your net savings after accounting for implementation costs.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div style={{ width: '100%', height: 400 }}>
          <ResponsiveContainer>
            <LineChart
              data={results.chart_data}
              margin={{
                top: 5, right: 30, left: 20, bottom: 5,
              }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" label={{ value: 'Months', position: 'insideBottom', offset: -5 }} />
              <YAxis tickFormatter={(value) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', notation: 'compact' }).format(value as number)} />
              <Tooltip formatter={(value) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(value as number)} />
              <Legend />
              <Line type="monotone" dataKey="savings" name="Net Savings" stroke="#10b981" strokeWidth={3} dot={false} activeDot={{ r: 8 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
};

export default SavingsChart;
