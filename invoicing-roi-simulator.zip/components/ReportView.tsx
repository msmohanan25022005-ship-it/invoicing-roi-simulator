
import React from 'react';
import { SimulationInput, SimulationOutput } from '../types';

interface ReportViewProps {
  inputs: SimulationInput | null;
  results: SimulationOutput | null;
}

const ReportView: React.FC<ReportViewProps> = ({ inputs, results }) => {
  if (!inputs || !results) return null;

  const formatCurrency = (value: number) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(value);
  const formatNumber = (value: number) => new Intl.NumberFormat('en-US', { maximumFractionDigits: 1 }).format(value);
  const formatPercentage = (value: number) => isFinite(value) ? `${formatNumber(value)}%` : '∞ %';

  return (
    <div id="print-area" className="p-8 text-black bg-white">
      <div className="text-center border-b-2 border-gray-300 pb-4 mb-8">
        <h1 className="text-4xl font-bold text-gray-800">Invoicing Automation ROI Report</h1>
        <p className="text-lg text-gray-600 mt-2">Scenario: {inputs.scenario_name}</p>
        <p className="text-sm text-gray-500">Generated on: {new Date().toLocaleDateString()}</p>
      </div>

      <div className="grid grid-cols-2 gap-x-12">
        <section className="mb-8">
          <h2 className="text-2xl font-semibold border-b pb-2 mb-4">Key Metrics Summary</h2>
          <div className="space-y-3">
            <ReportMetric label="Projected Monthly Savings" value={formatCurrency(results.monthly_savings)} />
            <ReportMetric label="Net Savings" value={formatCurrency(results.net_savings)} details={`over ${results.time_horizon_months} months`} />
            <ReportMetric label="Return on Investment (ROI)" value={formatPercentage(results.roi_percentage)} />
            <ReportMetric label="Payback Period" value={`${formatNumber(results.payback_months)} Months`} />
          </div>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold border-b pb-2 mb-4">Your Business Inputs</h2>
          <div className="space-y-3">
            <ReportMetric label="Monthly Invoice Volume" value={formatNumber(inputs.monthly_invoice_volume)} />
            <ReportMetric label="AP Staff" value={String(inputs.num_ap_staff)} />
            <ReportMetric label="Average Hourly Wage" value={formatCurrency(inputs.hourly_wage)} />
            <ReportMetric label="Time Horizon" value={`${inputs.time_horizon_months} Months`} />
            <ReportMetric label="Implementation Cost" value={formatCurrency(inputs.one_time_implementation_cost)} />
          </div>
        </section>
      </div>

      <section>
        <h2 className="text-2xl font-semibold border-b pb-2 mb-4">Cost Breakdown (Monthly)</h2>
        <div className="grid grid-cols-3 gap-4 text-center">
            <div className="p-4 bg-red-50 rounded-lg">
                <p className="text-sm text-red-700 font-semibold">Manual Process Cost</p>
                <p className="text-2xl font-bold text-red-900">{formatCurrency(results.manual_cost_per_month)}</p>
            </div>
             <div className="p-4 bg-blue-50 rounded-lg">
                <p className="text-sm text-blue-700 font-semibold">Automated Process Cost</p>
                <p className="text-2xl font-bold text-blue-900">{formatCurrency(results.automation_cost_per_month)}</p>
            </div>
             <div className="p-4 bg-green-50 rounded-lg">
                <p className="text-sm text-green-700 font-semibold">Error Reduction Savings</p>
                <p className="text-2xl font-bold text-green-900">{formatCurrency(results.error_savings_per_month)}</p>
            </div>
        </div>
      </section>

      <footer className="text-center text-xs text-gray-400 mt-12 pt-4 border-t">
        This report is a simulation based on the provided inputs and our internal ROI model. Actual results may vary.
      </footer>
    </div>
  );
};

const ReportMetric: React.FC<{ label: string; value: string; details?: string }> = ({ label, value, details }) => (
  <div className="flex justify-between items-baseline">
    <p className="text-gray-600">{label}:</p>
    <div className="text-right">
      <p className="font-bold text-lg text-gray-800">{value}</p>
      {details && <p className="text-xs text-gray-500">{details}</p>}
    </div>
  </div>
);

export default ReportView;
