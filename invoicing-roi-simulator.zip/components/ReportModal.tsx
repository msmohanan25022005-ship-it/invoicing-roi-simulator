
import React, { useState } from 'react';
import { Button } from './ui/Button';
import { Input } from './ui/Input';
import { Label } from './ui/Label';

interface ReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (email: string) => void;
}

const ReportModal: React.FC<ReportModalProps> = ({ isOpen, onClose, onSubmit }) => {
  const [email, setEmail] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      onSubmit(email);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex justify-center items-center">
      <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-md m-4">
        <form onSubmit={handleSubmit}>
          <h2 className="text-xl font-bold mb-4">Generate Your Report</h2>
          <p className="text-slate-600 mb-4">
            Enter your email address below to receive a downloadable PDF copy of your ROI analysis.
          </p>
          <div className="space-y-2">
            <Label htmlFor="email-report">Email Address</Label>
            <Input
              id="email-report"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@company.com"
              required
            />
          </div>
          <div className="mt-6 flex justify-end space-x-3">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit">
              Download Report
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ReportModal;
