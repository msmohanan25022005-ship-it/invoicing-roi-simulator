
import React from 'react';
import { SimulationOutput } from '../types';
import { Card, CardContent, CardHeader, CardTitle } from './ui/Card';
import { Button } from './ui/Button';

interface ResultsDisplayProps {
  results: SimulationOutput;
  onGenerateReport: () => void;
}

const ResultsDisplay: React.FC<ResultsDisplayProps> = ({ results, onGenerateReport }) => {
    
  const formatCurrency = (value: number) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(value);
  const formatNumber = (value: number) => new Intl.NumberFormat('en-US', { maximumFractionDigits: 1 }).format(value);
  const formatPercentage = (value: number) => {
    if (!isFinite(value)) return '∞ %';
    return `${formatNumber(value)}%`;
  }

  return (
    <Card className="shadow-lg">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-2xl font-bold">Projected Savings</CardTitle>
        <Button onClick={onGenerateReport}>
          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
          </svg>
          Generate Report
        </Button>
      </CardHeader>
      <CardContent>
        <div className="grid gap-4 md:grid-cols-3">
          <MetricCard title="Monthly Savings" value={formatCurrency(results.monthly_savings)} description="Estimated savings each month after automation." />
          <MetricCard title="Payback Period" value={`${formatNumber(results.payback_months)} months`} description="Time to recover the initial implementation cost." />
          <MetricCard title="ROI" value={formatPercentage(results.roi_percentage)} description={`Over ${results.time_horizon_months} months`} />
        </div>
        <div className="text-center mt-6 text-slate-600">
            Over a <strong>{results.time_horizon_months}-month</strong> period, you could achieve a net savings of <strong className="text-green-600">{formatCurrency(results.net_savings)}</strong>.
        </div>
      </CardContent>
    </Card>
  );
};

interface MetricCardProps {
    title: string;
    value: string;
    description: string;
}

const MetricCard: React.FC<MetricCardProps> = ({ title, value, description }) => (
    <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{title}</CardTitle>
        </CardHeader>
        <CardContent>
            <div className="text-2xl font-bold text-blue-600">{value}</div>
            <p className="text-xs text-muted-foreground text-slate-500">{description}</p>
        </CardContent>
    </Card>
);


export default ResultsDisplay;
