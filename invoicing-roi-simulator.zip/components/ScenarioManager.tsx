
import React from 'react';
import { SavedScenario } from '../types';
import { Button } from './ui/Button';

interface ScenarioManagerProps {
  scenarioName: string;
  onSave: () => void;
  onLoad: (id: string) => void;
  onDelete: (id: string) => void;
  savedScenarios: SavedScenario[];
}

const ScenarioManager: React.FC<ScenarioManagerProps> = ({ onSave, onLoad, onDelete, savedScenarios }) => {
  return (
    <div className="space-y-4">
      <h2 className="text-xl font-semibold text-slate-800 border-b pb-2">Scenario Management</h2>
      <Button onClick={onSave} className="w-full">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-3 3m0 0l-3-3m3 3V4" />
        </svg>
        Save Current Scenario
      </Button>

      {savedScenarios.length > 0 && (
        <div className="space-y-2">
            <h3 className="text-sm font-medium text-slate-600">Saved Scenarios</h3>
          <ul className="max-h-60 overflow-y-auto border rounded-md divide-y">
            {savedScenarios.map(scenario => (
              <li key={scenario.id} className="p-2 flex justify-between items-center text-sm">
                <span className="font-medium truncate pr-2">{scenario.name}</span>
                <div className="flex space-x-1">
                  <Button variant="ghost" size="sm" onClick={() => onLoad(scenario.id)}>Load</Button>
                  <Button variant="destructive" size="sm" onClick={() => onDelete(scenario.id)}>Del</Button>
                </div>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default ScenarioManager;
