
import { SimulationInput, SavedScenario } from '../types';

const SCENARIOS_KEY = 'roi_scenarios';

export const getScenarios = (): SavedScenario[] => {
  try {
    const scenariosJSON = localStorage.getItem(SCENARIOS_KEY);
    return scenariosJSON ? JSON.parse(scenariosJSON) : [];
  } catch (error) {
    console.error("Failed to parse scenarios from localStorage", error);
    return [];
  }
};

export const saveScenario = (inputs: SimulationInput): SavedScenario => {
  const scenarios = getScenarios();
  const newScenario: SavedScenario = {
    id: new Date().toISOString(),
    name: inputs.scenario_name,
    inputs: { ...inputs },
    createdAt: new Date().toISOString(),
  };
  
  const updatedScenarios = [...scenarios, newScenario];
  localStorage.setItem(SCENARIOS_KEY, JSON.stringify(updatedScenarios));
  return newScenario;
};

export const getScenario = (id: string): SavedScenario | undefined => {
  const scenarios = getScenarios();
  return scenarios.find(s => s.id === id);
};


export const deleteScenario = (id: string): void => {
  const scenarios = getScenarios();
  const updatedScenarios = scenarios.filter(s => s.id !== id);
  localStorage.setItem(SCENARIOS_KEY, JSON.stringify(updatedScenarios));
};
