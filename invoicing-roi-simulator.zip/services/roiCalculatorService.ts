
import { SimulationInput, SimulationOutput } from '../types';

// Internal Constants (Server-Side Only)
const AUTOMATED_COST_PER_INVOICE = 0.20;
const ERROR_RATE_AUTO = 0.001; // 0.1%
const MIN_ROI_BOOST_FACTOR = 1.1;

export const calculateROI = (inputs: SimulationInput): SimulationOutput => {
  const {
    monthly_invoice_volume,
    num_ap_staff,
    avg_hours_per_invoice,
    hourly_wage,
    error_rate_manual,
    error_cost,
    time_horizon_months,
    one_time_implementation_cost,
  } = inputs;

  // 1. Manual labor cost per month
  const labor_cost_manual = num_ap_staff * hourly_wage * avg_hours_per_invoice * monthly_invoice_volume;

  // 2. Automation cost per month
  const auto_cost = monthly_invoice_volume * AUTOMATED_COST_PER_INVOICE;

  // 3. Error savings
  const error_savings = (error_rate_manual / 100 - ERROR_RATE_AUTO) * monthly_invoice_volume * error_cost;
  
  // 4. Monthly savings
  let monthly_savings = (labor_cost_manual + error_savings) - auto_cost;

  // 5. Apply bias factor
  monthly_savings = monthly_savings * MIN_ROI_BOOST_FACTOR;

  // 6. Cumulative & ROI
  const cumulative_savings = monthly_savings * time_horizon_months;
  const net_savings = cumulative_savings - one_time_implementation_cost;
  
  const payback_months = one_time_implementation_cost > 0 && monthly_savings > 0
    ? one_time_implementation_cost / monthly_savings
    : 0;

  const roi_percentage = one_time_implementation_cost > 0
    ? (net_savings / one_time_implementation_cost) * 100
    : Infinity;

  // Generate data for the chart
  const chart_data = Array.from({ length: time_horizon_months + 1 }, (_, i) => ({
    month: i,
    savings: Math.max(0, (monthly_savings * i) - one_time_implementation_cost),
  }));

  return {
    monthly_savings,
    payback_months,
    roi_percentage,
    net_savings,
    cumulative_savings,
    chart_data,
    manual_cost_per_month: labor_cost_manual,
    automation_cost_per_month: auto_cost,
    error_savings_per_month: error_savings,
    time_horizon_months
  };
};
