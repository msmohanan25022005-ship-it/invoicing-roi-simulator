
export interface SimulationInput {
  scenario_name: string;
  monthly_invoice_volume: number;
  num_ap_staff: number;
  avg_hours_per_invoice: number;
  hourly_wage: number;
  error_rate_manual: number;
  error_cost: number;
  time_horizon_months: number;
  one_time_implementation_cost: number;
}

export interface SimulationOutput {
  monthly_savings: number;
  payback_months: number;
  roi_percentage: number;
  net_savings: number;
  cumulative_savings: number;
  chart_data: { month: number; savings: number }[];
  manual_cost_per_month: number;
  automation_cost_per_month: number;
  error_savings_per_month: number;
  time_horizon_months: number;
}

export interface SavedScenario {
  id: string;
  name: string;
  inputs: SimulationInput;
  createdAt: string;
}
