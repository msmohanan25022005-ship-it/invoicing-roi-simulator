
import React, { useState, useEffect, useCallback } from 'react';
import { SimulationInput, SimulationOutput, SavedScenario } from './types';
import { calculateROI } from './services/roiCalculatorService';
import { getScenarios, saveScenario, deleteScenario, getScenario } from './services/scenarioService';
import InputForm from './components/InputForm';
import ResultsDisplay from './components/ResultsDisplay';
import SavingsChart from './components/SavingsChart';
import ScenarioManager from './components/ScenarioManager';
import ReportModal from './components/ReportModal';
import ReportView from './components/ReportView';

const initialInputs: SimulationInput = {
  scenario_name: 'Q4_Pilot',
  monthly_invoice_volume: 2000,
  num_ap_staff: 3,
  avg_hours_per_invoice: 0.17,
  hourly_wage: 30,
  error_rate_manual: 0.5,
  error_cost: 100,
  time_horizon_months: 36,
  one_time_implementation_cost: 50000,
};

const App: React.FC = () => {
  const [inputs, setInputs] = useState<SimulationInput>(initialInputs);
  const [results, setResults] = useState<SimulationOutput | null>(null);
  const [savedScenarios, setSavedScenarios] = useState<SavedScenario[]>([]);
  const [isReportModalOpen, setReportModalOpen] = useState(false);

  const runSimulation = useCallback(() => {
    const output = calculateROI(inputs);
    setResults(output);
  }, [inputs]);

  useEffect(() => {
    runSimulation();
  }, [runSimulation]);

  useEffect(() => {
    setSavedScenarios(getScenarios());
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setInputs(prev => ({ ...prev, [name]: name === 'scenario_name' ? value : Number(value) }));
  };
  
  const handleSaveScenario = () => {
    saveScenario(inputs);
    setSavedScenarios(getScenarios());
  };

  const handleLoadScenario = (id: string) => {
    const loadedScenario = getScenario(id);
    if (loadedScenario) {
      setInputs(loadedScenario.inputs);
    }
  };

  const handleDeleteScenario = (id: string) => {
    deleteScenario(id);
    setSavedScenarios(getScenarios());
  };

  const handleGenerateReport = (email: string) => {
    console.log(`Report requested by: ${email}`); // Simulate lead capture
    setReportModalOpen(false);
    setTimeout(() => window.print(), 300); // Allow modal to close before printing
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-white shadow-sm sticky top-0 z-10 no-print">
        <div className="max-w-7xl mx-auto py-4 px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl font-bold leading-tight text-slate-900">
            Invoicing ROI Simulator
          </h1>
          <p className="text-slate-500 mt-1">Visualize savings from invoicing automation.</p>
        </div>
      </header>
      <main className="py-10 no-print">
        <div className="max-w-7xl mx-auto sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-1">
              <div className="bg-white p-6 rounded-lg shadow-md space-y-6 sticky top-24">
                <InputForm inputs={inputs} onInputChange={handleInputChange} />
                <ScenarioManager 
                  scenarioName={inputs.scenario_name}
                  onSave={handleSaveScenario}
                  onLoad={handleLoadScenario}
                  onDelete={handleDeleteScenario}
                  savedScenarios={savedScenarios}
                />
              </div>
            </div>

            <div className="lg:col-span-2 space-y-8">
              {results && (
                <>
                  <ResultsDisplay results={results} onGenerateReport={() => setReportModalOpen(true)} />
                  <SavingsChart results={results} />
                </>
              )}
            </div>
          </div>
        </div>
      </main>
      
      <ReportModal
        isOpen={isReportModalOpen}
        onClose={() => setReportModalOpen(false)}
        onSubmit={handleGenerateReport}
      />

      <ReportView inputs={inputs} results={results} />
    </div>
  );
};

export default App;
